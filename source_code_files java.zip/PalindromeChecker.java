
import java.util.Scanner;

public class PalindromeChecker {
    public static void main(String[] args){
        Scanner sc =new Scanner(System.in);
        System.out.println("enter a word or phrase");
        String input=sc.nextLine().toLowerCase();
        String filtered=input.replaceAll("[^a-zA-z0-9]","");
        int left=0;
        int right=filtered.length()-1;
        boolean ispalindrome = true;
        while(left<right){
            if(filtered.charAt(left)!=filtered.charAt(right)){
                ispalindrome = false;
                break;
            }
            left++;
            right--;
        }
        System.out.println(input+(ispalindrome? "is a palindrome.":" is not a palindrome."));                                 

    }
    
}
