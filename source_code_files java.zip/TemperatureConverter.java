package task1;
import java.util.Scanner;

public class TemperatureConverter {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter temperature value: ");
        double temp = input.nextDouble();
        System.out.println("Enter unit(C for Celsius,F for Fahrenheit):");
        char unit=input.next().charAt(0);
        if (unit=='C'){
            double fahrenheit=(temp*9/5)+32;
            System.out.printf("%.2f C is equal to %.2f F%n",temp,fahrenheit);
        } else if(unit =='F'){
            double celsius =(temp -32)*5/9;
            System.out.printf("%.2f F is equal to %.2f C%n",temp,celsius);
        }


    }
}