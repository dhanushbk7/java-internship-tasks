package level3;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Calculator implements ActionListener {
    JFrame frame;
    JTextField textField;
    JButton[] numberButtons = new JButton[10];
    JButton addButton, subtractButton, multiplyButton, divideButton, decimalButton, equalsButton, clearButton;
    JPanel panel;

    Font font = new Font("Arial", Font.BOLD, 20);
    double number1 = 0, number2 = 0, result = 0;
    char operation;

    public Calculator() {
        createGUI();
    }

    private void createGUI() {
        // Frame setup
        frame = new JFrame("Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500);
        frame.setLayout(null);  // Using null layout for manual component placement

        // Text field setup
        textField = new JTextField();
        textField.setBounds(30, 25, 320, 50);
        textField.setFont(font);
        textField.setEditable(false);
        frame.add(textField);

        // Panel for buttons
        panel = new JPanel();
        panel.setBounds(40, 100, 320, 300);
        panel.setLayout(new GridLayout(4, 4, 10, 10));  // 4x4 grid with 10px spacing
        frame.add(panel);

        // Number buttons
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].setFont(font);
            numberButtons[i].addActionListener(this);
        }

        // Operation buttons
        addButton = createButton("+");
        subtractButton = createButton("-");
        multiplyButton = createButton("*");
        divideButton = createButton("/");
        decimalButton = createButton(".");
        equalsButton = createButton("=");
        clearButton = createButton("C");

        // Add buttons to panel
        panel.add(numberButtons[7]);
        panel.add(numberButtons[8]);
        panel.add(numberButtons[9]);
        panel.add(divideButton);

        panel.add(numberButtons[4]);
        panel.add(numberButtons[5]);
        panel.add(numberButtons[6]);
        panel.add(multiplyButton);

        panel.add(numberButtons[1]);
        panel.add(numberButtons[2]);
        panel.add(numberButtons[3]);
        panel.add(subtractButton);

        panel.add(decimalButton);
        panel.add(numberButtons[0]);
        panel.add(equalsButton);
        panel.add(addButton);

        // Add clear button below the panel
        clearButton.setBounds(150, 420, 100, 50);  // Positioning the clear button manually
        frame.add(clearButton);

        frame.setVisible(true);
    }

    // Create buttons with action listeners
    private JButton createButton(String label) {
        JButton button = new JButton(label);
        button.setFont(font);
        button.addActionListener(this);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle number buttons
        for (int i = 0; i < 10; i++) {
            if (e.getSource() == numberButtons[i]) {
                textField.setText(textField.getText() + i);
            }
        }

        // Handle decimal button
        if (e.getSource() == decimalButton) {
            if (!textField.getText().contains(".")) {
                textField.setText(textField.getText() + ".");
            }
        }

        // Handle operation buttons
        if (e.getSource() == addButton) {
            calculate('+');
        } else if (e.getSource() == subtractButton) {
            calculate('-');
        } else if (e.getSource() == multiplyButton) {
            calculate('*');
        } else if (e.getSource() == divideButton) {
            calculate('/');
        } else if (e.getSource() == equalsButton) {
            number2 = Double.parseDouble(textField.getText());
            computeResult();
            textField.setText(String.valueOf(result));
        } else if (e.getSource() == clearButton) {
            textField.setText("");
            number1 = 0;
            number2 = 0;
            result = 0;
        }
    }

    // Method to capture the first number and operation
    private void calculate(char op) {
        number1 = Double.parseDouble(textField.getText());
        operation = op;
        textField.setText("");
    }

    // Method to perform the operation based on the selected operator
    private void computeResult() {
        switch (operation) {
            case '+' -> result = number1 + number2;
            case '-' -> result = number1 - number2;
            case '*' -> result = number1 * number2;
            case '/' -> {
                if (number2 == 0) {
                    JOptionPane.showMessageDialog(frame, "Cannot divide by zero", "Error", JOptionPane.ERROR_MESSAGE);
                    result = 0;
                } else {
                    result = number1 / number2;
                }
            }
            default -> result = 0;
        }
    }

    public static void main(String[] args) {
        new Calculator();
    }
}
