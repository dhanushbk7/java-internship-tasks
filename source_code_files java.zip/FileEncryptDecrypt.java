package level2.task2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileEncryptDecrypt {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Do you want to (E)ncrypt or (D)ecrypt?");
        char choice = scanner.next().charAt(0);

        System.out.println("Enter the file path:");
        String filePath = scanner.next();

        System.out.println("Enter the shift value (for Caesar cipher):");
        int shift = scanner.nextInt();

        try {
            File file = new File(filePath);
            Scanner fileScanner = new Scanner(file);
            StringBuilder content = new StringBuilder();
            while (fileScanner.hasNextLine()) {
                content.append(fileScanner.nextLine()).append("\n");
            }
            fileScanner.close();

            String processedContent = processContent(content.toString(), choice, shift);

            String newFilePath = choice == 'E' ? filePath + "_encrypted.txt" : filePath + "_decrypted.txt";
            FileWriter writer = new FileWriter(newFilePath);
            writer.write(processedContent);
            writer.close();

            System.out.println("File processed successfully. Saved to: " + newFilePath);
        } catch (IOException e) {
            System.out.println("An error occurred");
            e.printStackTrace();
        }
    }

    private static String processContent(String content, char choice, int shift) {
        StringBuilder result = new StringBuilder();
        for (char character : content.toCharArray()) {
            if (choice == 'E') {
                result.append((char) (character + shift));
            } else if (choice == 'D') {
                result.append((char) (character - shift));
            }
        }
        return result.toString();
    }
}
