package task3;

import java.util.Scanner;

public class StudentGradeCalculator{
    public static void main (String[]args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number of grades:");
        int numgrades=sc.nextInt();
        double sum=0;
        for(int i=0;i<numgrades;i++){
            System.out.println("enter grade"+(i+1)+":");
            sum +=sc.nextDouble();
        }
        double average=sum/numgrades;
        System.out.printf("the average grade is:%.2f%n" , average);
    }

    
}
