package level2.task1;
import java.util.Scanner;  

public class PasswordStrengthChecker {  
    public static void main(String[] args) {  
        Scanner scanner = new Scanner(System.in);  
        System.out.println("Enter your password:");  
        String password = scanner.nextLine();  
        
        boolean hasLength = password.length() >= 8;  
        boolean hasUppercase = !password.equals(password.toLowerCase());  
        boolean hasLowercase = !password.equals(password.toUpperCase());  
        boolean hasNumber = password.matches(".*\\d.*");  
        boolean hasSpecial = password.matches(".*[^a-zA-Z0-9].*");  
        
        int strength = 0;  
        if (hasLength) strength++;  
        if (hasUppercase) strength++;  
        if (hasLowercase) strength++;  
        if (hasNumber) strength++;  
        if (hasSpecial) strength++;  
        
        String rating;  
        if (strength >= 4) rating = "Strong";  
        else if (strength >= 2) rating = "Medium";  
        else rating = "Weak";  
        
        System.out.println("Password Strength: " + rating);  
    }  
} 
