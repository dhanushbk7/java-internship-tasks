import java.security.SecureRandom;
import java.util.Scanner;  

public class RandomPasswordGenerator {  

    private static final String LOWER_CASE = "abcdefghijklmnopqrstuvwxyz";  
    private static final String UPPER_CASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";  
    private static final String NUMBERS = "0123456789";  
    private static final String SPECIAL_CHARACTERS = "!@#$%^&*()_+{}[]\\|;:,.<>?/~\"";  
    
    private static SecureRandom random = new SecureRandom();  

    public static void main(String[] args) {  
        Scanner sc = new Scanner(System.in);  
        System.out.println("Welcome to the Password Generator!");  
        System.out.println("-------------------------------");  
        
        boolean generateAnother;  
        do {  
            int length = getValidPasswordLength(sc);  
            boolean includeNumbers = getUserPreference(sc, "Include numbers? (yes/no)");  
            boolean includeUpperCase = getUserPreference(sc, "Include upper case letters? (yes/no)");  
            boolean includeSpecialCharacters = getUserPreference(sc, "Include special characters? (yes/no)");  

            String chars = constructCharacterSet(includeNumbers, includeUpperCase, includeSpecialCharacters);  
            String password = generatePassword(length, chars);  

            System.out.println("\nGenerated password: " + password);  
            System.out.println("Length: " + length);  
            System.out.println("Includes numbers: " + includeNumbers);  
            System.out.println("Includes upper case letters: " + includeUpperCase);  
            System.out.println("Includes special characters: " + includeSpecialCharacters);  
            
            System.out.println("\nWould you like to generate another password? (yes/no)");  
            generateAnother = sc.next().equalsIgnoreCase("yes");  
        } while (generateAnother);  

        System.out.println("\nThank you for using the Password Generator!");  
    }  

    private static int getValidPasswordLength(Scanner sc) {  
        while (true) {  
            try {  
                System.out.println("Enter the desired password length (minimum 8 recommended):");  
                int length = sc.nextInt();  
                if (length < 8) {  
                    System.out.println("Password length should be at least 8 characters for security reasons.");  
                }  
                return length;  
            } catch (Exception e) {  
                System.out.println("Invalid input. Please enter a valid number.");  
                sc.next(); // Consume invalid input  
            }  
        }  
    }  

    private static boolean getUserPreference(Scanner sc, String prompt) {  
        while (true) {  
            System.out.println(prompt);  
            String input = sc.next().toLowerCase();  
            if (input.equals("yes")) {  
                return true;  
            } else if (input.equals("no")) {  
                return false;  
            } else {  
                System.out.println("Please enter 'yes' or 'no'.");  
            }  
        }  
    }  

    private static String constructCharacterSet(boolean includeNumbers, boolean includeUpperCase, boolean includeSpecialCharacters) {  
        StringBuilder chars = new StringBuilder(LOWER_CASE);  
        if (includeNumbers) chars.append(NUMBERS);  
        if (includeUpperCase) chars.append(UPPER_CASE);  
        if (includeSpecialCharacters) chars.append(SPECIAL_CHARACTERS);  
        return chars.toString();  
    }  

    private static String generatePassword(int length, String chars) {  
        StringBuilder password = new StringBuilder();  
        for (int i = 0; i < length; i++) {  
            int index = random.nextInt(chars.length());  
            password.append(chars.charAt(index));  
        }  
        return shuffleString(password.toString(), random);  
    }  

    private static String shuffleString(String input, SecureRandom random) {  
        char[] chars = input.toCharArray();  
        for (int i = 0; i < chars.length; i++) {  
            int randomIndex = random.nextInt(chars.length);  
            char temp = chars[i];  
            chars[i] = chars[randomIndex];  
            chars[randomIndex] = temp;  
        }  
        return new String(chars);  
    }  
} 

